
public class MyMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		hourGlass2(9);
		hourGlass2(12);
		NxN(2);
		Fibonacci(10);
	}

	public static void hourGlass2(int oddSize){
		int a=oddSize,count=1;
		while(a>0){
			for(int i=2;i<=count;i++){
				System.out.printf(" ");
			}
			for(int i=1;i<=a;i++){
				System.out.printf("*");
			}
			for(int i=1;i<=count;i++){
				System.out.printf(" ");
			}
			System.out.println();
			a-=2;
			count++;
		}
		a+=4;
		count-=2;
		while(a<=oddSize){
			for(int i=2;i<=count;i++){
				System.out.printf(" ");
			}
			for(int i=1;i<=a;i++){
				System.out.printf("*");

			}
			for(int i=1;i<=count;i++){
				System.out.printf(" ");
			}
			System.out.println();
			a+=2;
			count--;
		}
		System.out.println();
	}

	public static void NxN(int n){
		for(int p=1;p<=n;p++){
			for(int i=1;i<=9;i++){
				for(int j=1;j<=9;j++){
					if(j%n==p){
						System.out.printf("%d*%d=%d",j,i,i*j);
						System.out.printf("\t");
					}
					if(p==n&&j%n==0){
						System.out.printf("%d*%d=%d",j,i,i*j);
						System.out.printf("\t");
					}
				}
				System.out.println();
			}
			System.out.println();
		}		
	}

	public static void Fibonacci(int n){
		int n1=1,n2=1,n3;
		for(int i=1;i<=n;i++){
			if(i<=2){
				System.out.printf("%d\t",n1);
			}
			if(i>2){
				n3=n1+n2;
				n1=n2;
				n2=n3;
				System.out.printf("%d\t",n3);
			}
		}
	}
}

